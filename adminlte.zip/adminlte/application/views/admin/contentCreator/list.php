<?php $this->load->view('admin/header'); ?>





  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>List of Content Creators</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr No.</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Username</th>
					  <th>Email</th>
                    <th>Total unbox</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
				<?php
				$x=0;
				$creator=$this->db->get_where('content_creator',array('role'=>1))->result();
					  foreach($creator as $item){
				$x++;
				 ?>
                  <tr>
                    <td><?=$x?></td>
                    <td>
                      <img src="<?=base_url()?>upload/<?=$item->profileImage?>" class="img-fluid rounded-circle" width="80">
                    </td>
                    <td><?=$item->name?></td>
                    <td><?=$item->userName?></td>
                    <td><?=$item->email?></td>
                    <td><?=$item->dob?></td>
					<td><?=$item->status?></td>
                    <td>
                      <a href="/Admin/contentCreatorAdd/<?=$item->id?>" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit"><i class="far fa-edit"></i></a>
                      <a href="/Admin/dellContentCreator/<?=$item->id?>" class="btn btn-danger dell" data-toggle="tooltip" data-placement="top" title="Delete"><i class="far fa-trash-alt"></i></a>
					 <?php
				if($item->status == 'ban'){
				?>
                <a href="/Admin/unbanContentCreator/<?=$item->id?>" type="button" class="btn btn-success">Unban</a>
                <?php
				}
				elseif($item->status == 'Unban'){
				?>
                <a href="/Admin/banContentCreator/<?=$item->id?>" type="button" class="btn btn-warning">Ban</a>
						
                <?php } ?>

                      <a href="/Admin/contentCreatorPrifile/<?=$item->id?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="View User Detail"><i class="far fa-eye"></i></a>
				<a href="/Admin/paymentReportDetail/<?=$item->id?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="View Payment Report"><i class="far fa-credit-card "></i></a>
				<a href="/Admin/myBoxList/<?=$item->id?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="View My Boxes"><i class="fas fa-box-open"></i></a>
				
                    </td>
                  </tr>
					<?php }?>
                  
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<script>
	$('.dell').click(function (){

	if(confirm('are you sure?')){

		return true;

		}else

	return false;

	});
</script>
<?php $this->load->view('admin/footer'); ?>